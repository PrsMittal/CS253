.mode csv
.import students.csv student
