insert into offering values ("CS250", 2019, 2, 2323);
insert into offering values ("CS250", 2020, 2, 3210);
insert into offering values ("ECO101", 2020, 2, 7878);

insert into registration values ("CS250", 11234, 2019, 2, "A");
insert into registration values ("CS250", 11236, 2019, 2, "C");
insert into registration values ("CS250", 11239, 2020, 2, "A");
insert into registration values ("ECO101", 11239, 2020, 2, "A");
insert into registration values ("ECO101", 11344, 2020, 2, "B");

