insert into department values (12, "AE");
insert into department values (14, "ECO");
insert into department values (18, "CSE");

insert into course values ("CS250", "Lab Tools", 9, null);
insert into course values ("CS315", "Databases", 12, "web.cse.iitk.ac.in/users/cs315/");
insert into course values ("ECO101", "Introduction to Economics", 11, "eco.iitk.ac.in");
insert into course values ("AE102", "Introduction to Flying", 11, null);

insert into faculty values (2323, "AK", 18, "P");
insert into faculty values (3210, "SS", 18, "P");
insert into faculty(fid, name, dept) values (7878, "AB", 14);

